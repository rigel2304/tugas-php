<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas 1 PHP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f4f4f9;
        }
        .container {
            max-width: 450px;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }
        button:hover {
            background-color: #0056b3;
        }
        .result {
            margin-top: 20px;
            padding: 15px;
            border-radius: 5px;
        }
        .lulus {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .remedial {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Form Nilai Ujian</h2>
    
    <!-- Form input  -->
    <form method="POST" action="">
        <div class="form-group">
            <label for="nama">Nama:</label>
            <input type="text" id="nama" name="nama" required>
        </div>
        
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        
        <div class="form-group">
            <label for="nilai">Nilai Ujian:</label>
            <input type="number" id="nilai" name="nilai" min="0" max="100" required>
        </div>
        
        <button type="submit" name="submit">Kirim Data</button>
    </form>

    <?php
    // Form processing 
    if (isset($_POST['submit'])) {
        $nama = htmlspecialchars($_POST['nama']);
        $email = htmlspecialchars($_POST['email']);
        $nilai = (float) $_POST['nilai'];

        // Struktur kendali 
        if ($nilai > 70) {
            $status = "Lulus";
            $class_css = "lulus";
        } else {
            $status = "Remedial";
            $class_css = "remedial";
        }

        // Output hasil pemrosesan
        echo "<div class='result {$class_css}'>";
        echo "<h3>Hasil Processing:</h3>";
        echo "<p><strong>Nama:</strong> {$nama}</p>";
        echo "<p><strong>Email:</strong> {$email}</p>";
        echo "<p><strong>Nilai Ujian:</strong> {$nilai}</p>";
        echo "<p><strong>Status:</strong> {$status}</p>";
        echo "</div>";
    }
    ?>
</div>

</body>
</html>